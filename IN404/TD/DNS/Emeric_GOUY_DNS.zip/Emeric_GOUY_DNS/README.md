DNS
-----
+ compilation : `javac *.java`
+ exécution : `java DNSApp`
+ Le fichier `defaultProperties.properties` contient un champ `filename`, représentant le nom du fichier dans lequel la base de données est lue.
