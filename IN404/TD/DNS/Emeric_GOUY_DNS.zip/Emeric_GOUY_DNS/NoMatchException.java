public class NoMatchException extends Exception{
    public NoMatchException(String m){
        super(m);
    }
}
