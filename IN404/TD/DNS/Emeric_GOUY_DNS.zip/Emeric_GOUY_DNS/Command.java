public interface Command {
    String execute(DNS db);
}
