public class Quit implements Command {
    @Override
    public String execute(DNS db) {
        return "";
    }
}
